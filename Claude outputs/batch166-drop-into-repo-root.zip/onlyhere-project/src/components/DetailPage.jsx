import { useEffect, useState } from "react";
import { activeCountry, DEFAULT_COUNTRY } from "../utils/countries";
import { C } from "../utils/theme";
import { getEventDate, travelLabel, isUpcoming, isCurrentlyLive, arrivalRow, externalHref, hasFinished, TRAVEL_ORIGIN } from "../utils/helpers";
import { byEventDate } from "../utils/eventDates";
import { relationLine, kindLabel, areasInside } from "../utils/placeKind";
import { pricedLine } from "../utils/provenance";
import { withLiveReels } from "../utils/reelGate";
import { ticketLabelLine, ticketProvenance } from "../utils/tickets";
// ── "ATTRACTIONS ALL SAY FREE" ────────────────────────────────────
// Oliver, 27 Aug 2026. The badge below appended a literal "· FREE" to every
// attraction in the pool, because the pool's Studio type is called `free` and
// it used to mean it. It holds Legoland now. See utils/entryPrice.js.
import { AttractionBadge } from "./AttractionBadge";
// ── "HIGH-END" AND "CASUAL" ───────────────────────────────────────
// Oliver, 27 Aug 2026, relaying his friend. See utils/venueStyle.js.
import { VenueStyleChip } from "./VenueStyleChip";
import { AtAGlanceCard } from "./AtAGlanceCard";
import { GemlyxFindCard } from "./GemlyxFindCard";
import { InstagramEmbed } from "./InstagramEmbed";
import { ReviewsSection } from "./ReviewsSection";
import { ArticleFeedback } from "./ArticleFeedback";
import { PhotoCredit } from "./PhotoCredit";
import { PlaceMiniMap } from "./PlaceMiniMap";
import { ticketmasterUrl, ticketDisclosure, tiqetsUrl, tiqetsDisclosure, affiliateHref, affiliateNote, isWegotripUrl, outboundLink } from "../utils/affiliates";
import { isTiqetsProductUrl, ticketAgentOf, isBookableTicketUrl, isTourUrl, sameShop, priceSourceHost, isResellerUrl } from "../utils/ticketLink";
import { cleanTicketOffer, offerIsTheDoor, ticketOfferLine, partnerReason, partnerPitchFits, officialSiteLabel, agentName, OFFER_AGENTS } from "../utils/ticketOffer";
import { branchPoints, branchesOf, hasBranches, branchLine, branchLabel } from "../utils/branches";
import { offerView, OFFER_LOCKED_LABEL, OFFER_LOCKED_NOTE, OFFER_NOTE } from "../utils/offer";
import { saveLabel, saveHint, planFromSavedLabel } from "../utils/savedTrip";
import { HowWeKnow } from "./HowWeKnow";
import { SocialSection } from "./SocialSection";
import { JourneyCard } from "./JourneyCard";
import { showsJourneyForKind, journeyOriginForKind, showsTicketForKind } from "../utils/journeyScope";
import { arrivalOrBusRow, busStopRow } from "../utils/busStop";
import { audioLine } from "../utils/wegotripMatch";
// ── AND THE WORDS ON THIS PAGE, IN THE READER'S LANGUAGE ────────────
// Oliver, 7 Sep 2026: "translating more of the website from English to Danish
// and German, rather than just the interface." A Danish nav over an entry whose
// every word is English is the half-translation uiLanguage.js already calls
// worse than none. `lang` arrives as a prop from App.jsx, which holds it.
import { t as uiT, DEFAULT_UI_LANGUAGE } from "../utils/uiLanguage";
import { entryWord, bookLabel } from "../utils/entryWords";
import { readableOn } from "../utils/readableColor";
import { events, majorEvents, vikingEvents } from "../data/events";
// ── THE ESSENTIALS THAT BELONG TO ONE PLACE ─────────────────────────
// Read straight from the data module, the way the events above are: liveContent
// pushes the published rows into that same array, so this sees whatever Studio
// has published without a prop being threaded through App.jsx for it.
import { essentials } from "../data/essentials";
import { essentialsForPlace } from "../utils/essentialPlace";
import { kindOf as essentialKindOf, linksOf } from "../utils/essentialKind";
import { freeEntrance } from "../data/freeEntrance";
import { foodSpots } from "../data/food";
import { nightlifeSpots } from "../data/nightlife";
import { towns, TOWN_COORDS } from "../data/towns";
import { haversineKm } from "../utils/helpers";
import { placeCoords, townPointFor } from "../utils/guideEnrichment";
import { placedLibrary, nearbyPublished, SAME_VISIT_KM, SAME_VISIT_LIMIT } from "../utils/nearbyPlaces";
import { layoutBody, trimCaption } from "../utils/articleLayout";
import { isOperatorSite, hasFerryDoor, ferryUrlOf, FERRY_DOOR_LABEL } from "../utils/ferryDoor";

// layoutBody moved to utils/articleLayout.js on 21 Aug 2026 so the suite can
// actually run it. See the comment there: living in this .jsx file is the
// reason a bug that switched the whole feature off went unnoticed.

// Which published festivals genuinely belong to this town.
//
// Deliberately strict, because the whole value of this section is that a
// traveler can trust it. A festival is only shown here when its own `town`
// field really names this town, matched case-insensitively on whole words
// after trimming, never as a loose substring. A loose match would happily
// claim "Køge Festuge" for a town called "Køge Bugt", or attach every
// Copenhagen event to a place whose name merely contains "Copenhagen".
//
// Live events come first (they are happening right now, which is the most
// useful thing a traveler can be told), then upcoming ones by date. Anything
// already finished is dropped entirely rather than shown greyed out: a past
// festival on a town page is noise, not information.
const inThisTown = (e, key) => {
  const t = String(e.town || "").trim().toLowerCase();
  if (!t) return false;
  // "Sønderho, Fanø" and "Ribe" both need to work, so split on commas and
  // slashes and compare each part exactly, rather than using includes().
  return t.split(/[,/]/).map(s => s.trim()).includes(key);
};

// Straight-line km between two known towns, or null when either coordinate is
// missing. NULL IS THE POINT: it means "we do not know", and an unknown distance
// must never become a displayed number. Same discipline as legDistanceKm in the
// guide code, for the same reason it had to be added there.
//
// haversineKm, not a fourth hand-rolled flat-earth formula. This one carried
// `* 62.06` for a longitude degree with "shorter at Denmark's latitude" beside
// it, which is cos(56.1 N) worked out once and then frozen — right in the middle
// of the country and wrong at both ends of it. haversineKm is exact everywhere,
// is already imported by four other files, and is tested.
const kmBetweenTowns = (a, b) => {
  const A = TOWN_COORDS[a], B = TOWN_COORDS[b];
  if (!Array.isArray(A) || !Array.isArray(B)) return null;
  const km = haversineKm({ lat: A[0], lon: A[1] }, { lat: B[0], lon: B[1] });
  return Number.isFinite(km) ? km : null;
};

// A festival in a DIFFERENT town, close enough to matter, with a real measured
// distance. This exists because of what the published data actually looks like:
// checked against the live database, only 2 of 16 published towns have a
// festival whose town field names them, while 18 published festivals sit in
// towns that have no published town entry (Skanderborg, Jelling, Aarhus and so
// on). Without this, the section would almost never appear.
//
// It stays honest three ways: the distance is computed from real coordinates
// (never estimated, and the row is dropped entirely when either town is missing
// from TOWN_COORDS), the real host town is always named, and it renders under a
// separate "Nearby" heading so it can never be read as "happening here".
const NEARBY_MAX_KM = 45;
const nearbyEvents = (townName, key) => [...events, ...majorEvents]
  .filter(e => e.town && !inThisTown(e, key))
  .map(e => ({ e, km: kmBetweenTowns(townName, String(e.town).split(/[,/]/)[0].trim()) }))
  .filter(x => x.km != null && x.km <= NEARBY_MAX_KM)
  .sort((a, b) => a.km - b.km);

const eventsForTown = (townName) => {
  const key = String(townName || "").trim().toLowerCase();
  if (!key) return [];
  return [...events, ...majorEvents]
    .filter(e => inThisTown(e, key))
    // `e.date &&` matters: isUpcoming() returns TRUE for an empty date (it treats
    // "no date" as "not in the past"), which is right for the browse-everything
    // lists but wrong here. A dateless festival on a town page would render as
    // an event you could plan around when nobody actually knows when it runs.
    .filter(e => e.date && (isCurrentlyLive(e.date, e.dateEnd) || isUpcoming(e.date)))
    .sort((a, b) => {
      const liveA = isCurrentlyLive(a.date, a.dateEnd) ? 0 : 1;
      const liveB = isCurrentlyLive(b.date, b.dateEnd) ? 0 : 1;
      if (liveA !== liveB) return liveA - liveB;
      // byEventDate, not a second comparator. Same reasoning as the copy in
      // LiveEventsHeaderStrip: the order this produced was right, and it was
      // right by accident of both sides being parsed the same wrong way.
      return byEventDate(a, b);
    });
};

// ── WHAT ELSE IS NEAR THIS ─────────────────────────────────────────
// There used to be a `nearbyEntries` here: thirty lines answering the same
// question nearbyPlaces.js already answered, with its own flat-earth distance
// formula, its own radius, its own limit, and no tests. It read `__lat` alone,
// so every row carrying a plain `lat` was invisible to it — the same fault that
// reported no content in South Jutland — and it resolved the place differently
// from the pin beside it. The reasoning is written out at placedLibrary.
//
// One resolution now feeds both the pin and the dots, computed once below.

// ── WHERE THIS ENTRY IS ────────────────────────────────────────────
// placeCoords is the resolver the rest of the app uses: `__lat ?? lat`, and
// Number.isFinite rather than truthiness, so a missing coordinate is missing
// instead of becoming a point in the Gulf of Guinea.
//
// THE TOWN FALLBACK ONLY APPLIES TO A TOWN. A town's stored coordinate IS its
// centre, so falling back to TOWN_COORDS costs nothing there. Doing it for an
// attraction would plot it at the middle of whatever town its name contains —
// "Ribe VikingeCenter" lands on Ribe, three kilometres out — which is a guess
// printed as a pin. townPointFor rather than a raw TOWN_COORDS lookup because it
// tries the Danish spelling too, so a town filed as København still resolves.
export const detailPoint = (item, kind) =>
  placeCoords(item) || (kind === "town" ? townPointFor(item?.name) : null);

export const DetailPage = ({ item, onClose, kind, liveInfo, liveInfoLoading, checkLiveInfo, userCoords, isSaved, onToggleSave, hasBeen = false, onToggleBeen, savedCount = 0, onPlanFromSaved, onOpenEvent, onOpenNearby, paid = false, signedIn = false, onNeedAccount, lang = DEFAULT_UI_LANGUAGE, windowed = false }) => {
  // Folded away by default. See the events block below for why, and for why
  // the count sits on the row that opens it.
  const [eventsOpen, setEventsOpen] = useState(false);
  // ── A MISSING PHOTOGRAPH AND A BROKEN ONE ARE ONE STATE ───────────
  //
  // Oliver, 10 Sep 2026: "what to do with places where I can't find pictures..
  // shall we somehow collapse the events without pictures? So it's not an empty
  // box, but a collapsed frame."
  //
  // The empty box was not the no-photo case, which already draws the emoji at
  // full size. It was the BROKEN one: `item.photo` is truthy, so the header
  // styled itself as having a photograph, dropped the emoji to a quarter opacity
  // behind it, and then onError hid the image. A 190px band with a ghost in it,
  // and nothing anywhere could tell it from a page whose photo simply had not
  // been found yet.
  //
  // One state, decided before render, the way showablePhoto already does it for
  // the chat cards. Reset when the entry changes, or one bad image would collapse
  // the header of every entry opened after it.
  const [shotFailed, setShotFailed] = useState(false);
  useEffect(() => { setShotFailed(false); }, [item?.photo]);
  const hasShot = !!String(item?.photo || "").trim() && !shotFailed;
  // ── ESCAPE CLOSES A WINDOW ────────────────────────────────────────
  //
  // Oliver, 9 Sep 2026, on opening an entry from the chat: "a window that when
  // you click off it, it disappears as if you 'alt-f4' on it." Clicking off it
  // is handled on the backdrop below; a keyboard has the same expectation and
  // gets it here, which is also the one thing a person without a mouse has.
  //
  // BEFORE the early return, because a hook may not run conditionally. The
  // effect itself does nothing when there is no window open.
  useEffect(() => {
    if (!windowed || !item || typeof window === "undefined") return undefined;
    const onKey = (e) => { if (e.key === "Escape" && typeof onClose === "function") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [windowed, item, onClose]);
  if (!item) return null;
  const color = item.color || C.accent;
  // ── THE TICKET LINK, RESOLVED ONCE ────────────────────────────────
  //
  // Oliver, 7 Sep 2026: "is it possible to put the 'book tickets' on the 'at a
  // glance'? So people won't miss it."
  //
  // It was computed inside the button's own block near the bottom of this file,
  // so nothing above could reach it. Hoisted rather than copied: two readings
  // of "which link does this entry have" is how the pin and the neighbour dots
  // ended up disagreeing on this same page in August. Every refusal still
  // belongs to utils/ticketLink.js, and affiliateHref is still the one door.
  // Where the journey on this page was measured FROM, taken from the one file
  // that owns the rule rather than assumed by the line that prints it. A town
  // is measured from Copenhagen; everything else from its own town centre, and
  // the row wrote that name down when the measurement ran.
  const journeyOrigin = journeyOriginForKind(kind) === "origin"
    ? TRAVEL_ORIGIN
    : String(item?.__journey?.from || "").trim();
  // ── AND A TOWN HAS NO DOOR ─────────────────────────────────────
  //
  // Oliver, 19 Sep 2026, deciding this after the costs list stopped charging
  // admission for a town: "A town shouldn't. There are the 'events coming up'
  // tap that one should be able to click on."
  //
  // Both halves are his and both are right. Roskilde's town page offered 🎫
  // Book tickets, pointing at Roskilde Festival, because this row picked up a
  // ticketUrl and nothing here asked whether the PLACE has a way in. And the
  // route he names already exists and is the better one: the What's on rows
  // below are buttons, each opens that event's own page, and the ticket link
  // lives there beside its dates and its ticket status.
  //
  // GATED AT THE RENDER, which fixes every row already in the database rather
  // than needing a redraft each. The stored field is untouched, deliberately:
  // a music venue published as `night` may really sell dated tickets, and
  // dropping the value at publish would delete a working link from rows nobody
  // has looked at. See showsTicketForKind in utils/journeyScope.js.
  const ticketDest = !showsTicketForKind(kind)
    ? ""
    : String(item?.ticketUrl || "").trim()
      || (isBookableTicketUrl(item?.__ticket?.url) ? String(item.__ticket.url).trim() : "");
  const ticketAgent = ticketAgentOf(ticketDest);
  const ticketHref = ticketAgent ? (affiliateHref(ticketDest) || ticketDest) : "";
  const ticketNote = ticketAgent ? affiliateNote(ticketDest, lang) : "";
  // ── WHAT THE TIQETS PAGE SELLS, AND WHETHER THERE IS A DIRECT WAY ──
  //
  // Oliver, 28 Sep 2026: "recommending Amalienborg through Getyourguide or
  // zoo through Tiqets, is bad in the sense that it is 10 kr pricier.
  // However, some of them do include packages that make it cheaper and have
  // refunding." Asked how the two should sit: "Up to you."
  //
  // First answer, same evening: the site first and Tiqets as a quieter line.
  // His better one, below: both as equals. No price claim either way: he found
  // Tivoli cheaper on Tiqets (190 kr against 220 in Tivoli's own shop for 15 Oct), so a
  // "dearer" line is wrong on some days for some places. Where there
  // is no site of its own, Tiqets is the button, as before, with the reason
  // to use it under it when its ticket page gives one. And a page that
  // sells a guided tour or only the Copenhagen Card is offered as exactly that,
  // never under a Tickets label. See utils/ticketOffer.js.
  // ── AND ONLY A CHECKED ENTRY TICKET IS TICKETS ───────────────────
  // 29 Sep 2026, Fable's review: a link with no stored answer counted as
  // selling the door, so every row checked before 28 Sep still said "Book
  // tickets", Amalienborg's tour page among them. Now the default is the other
  // way: no answer, or an answer read off a different address, is "unknown",
  // and unknown is the quieter "Also on Tiqets" line. Ticketmaster and WeGoTrip
  // are untouched; their pages are events and a fixed catalogue.
  const offerAgent = OFFER_AGENTS.includes(ticketAgent);
  const ticketOffer = offerAgent ? (cleanTicketOffer(item?.__ticketOffer, ticketDest) || { kind: "unknown", agent: ticketAgent }) : null;
  const ticketSellsDoor = !offerAgent || offerIsTheDoor(ticketOffer);
  // The general partner sentence ("they often offer extra packages or refund
  // deals") only where it can be true; the commission alone everywhere else.
  const commissionOnly = ticketNote ? uiT("affiliate.commission", lang) : "";
  const offerNote = offerAgent && !partnerPitchFits(ticketOffer) ? commissionOnly : ticketNote;
  const hasDirectSite = (kind === "free" || kind === "event") && !!externalHref(item?.website) && !isResellerUrl(externalHref(item?.website));
  // Oliver, 28 Sep 2026: "Maybe we should just add both links? For people to
  // decide themselves?" So where both exist, the official site and Tiqets sit
  // side by side as equals, and the separate Website button steps aside so the
  // site is not offered twice.
  const showTicketPair = offerAgent && ticketSellsDoor && hasDirectSite;
  // The row shape AtAGlanceCard takes, or null when there is nothing to link.
  // Null rather than an empty object, because that card already drops nulls and
  // a caller building this inline should not have to remember to.
  //
  // ── AND THE SELF-GUIDED WALK, RESOLVED ONCE ─────────────────────
  //
  // Oliver, 8 Sep 2026: "I'd like the cities with 'self-guided tour' to have
  // that on the 'at a glance' if possible. Then it will be exposed earlier.
  // Also with an affiliate hyperlink."
  //
  // It was a button near the bottom of a town page, under the article, the
  // photographs and the journey. At a Glance is the first block under the
  // title, which is the same argument that put the ticket link there on 7 Sep:
  // "So people won't miss it."
  //
  // Hoisted rather than computed twice. The button below reads these too, so
  // the row and the button cannot disagree about which walk this is or where
  // it goes, which is the fault the ticket destination was hoisted to fix on
  // this same page in August.
  //
  // isWegotripUrl rather than a hand-written host test: this file had its own,
  // studioContent had none and costLedger had a bare scheme test, which is
  // three answers to one question. The scheme is still asked, because
  // isWegotripUrl accepts http and an anchor on a public page should not.
  const audioDest = String(item?.__audio?.url || "").trim();
  const audioOk = /^https:\/\//i.test(audioDest) && isWegotripUrl(audioDest);
  const audioHref = audioOk ? (affiliateHref(audioDest) || audioDest) : "";
  const audioNote = audioOk ? affiliateNote(audioDest, lang) : "";
  const audioCount = Number(item?.__audio?.count) || 1;
  const audioTown = String(item?.__audio?.town || "").trim() || String(item?.name || "").trim();
  const audioTitle = String(item?.__audio?.title || "").trim();
  // What the walk IS, as a sentence a reader can read before deciding to press
  // anything. The merchant is named on the LINK rather than in here, which is
  // the rule the button below already keeps: "a button pointing at a site
  // nobody has heard of has to say whose it is."
  //
  // THROUGH audioLine, which the Studio proposal already uses to show him what
  // the card will say. A sentence composed here would be the third copy of one
  // on this page, and this codebase has been bitten six times by exactly that.
  // `kind: false` because the row's LABEL says "Self-guided tour" and the
  // value would otherwise say it twice.
  const audioSaid = { url: audioDest, count: audioCount, title: audioTitle, town: audioTown };
  const audioSays = audioOk ? audioLine(audioSaid, { kind: false }) : "";
  const audioRow = audioHref ? { href: audioHref, label: "On WeGoTrip", note: audioNote } : null;

  // ── AND WHOSE PRICE THE ROW IS QUOTING ──────────────────────────
  //
  // Oliver, 8 Sep 2026: "199.. you click link, and it says 289." Every row the
  // link decorates carries a PRICE, and wowpark.dk's dated 199 sat beside a
  // Tiqets link selling a flexible ticket at 289.
  //
  // The first answer took the link off those rows, and it was wrong. Of the 192
  // published rows, 11 carry a ticket link and NOT ONE had its price read from
  // the shop selling it, so the rule fired on all 11 and Amalienborg Slot ended
  // up with a price, a guard change and no way to buy anything. He picked the
  // other answer: "many people might not scroll to the bottom and see 'order
  // tickets'. It's a good idea to have it early as well in the 'at a glance'."
  //
  // So the link comes back on every row and the row says where the number came
  // from, which is the thing a reader needed in the first place. The clause is
  // printed only when the two hosts DIFFER, because "125 DKK, stated by
  // tiqets.com, buy on Tiqets" is noise, and only when there is a link, because
  // an unlinked figure surprises nobody.
  //
  // sameShop still answers it. What changed is what the answer is for.
  const priceHost = priceSourceHost(item?.__priceSource);
  const bookSource = ticketHref && !sameShop(ticketDest, item?.__priceSource) ? priceHost : "";
  // THE MERCHANT ON THE LABEL, for the reason the WeGoTrip row above carries
  // its own: a link to a site nobody has heard of has to say whose it is, and
  // here it is also half of the answer, since the two hosts only read as
  // different if the reader is told both. bookLabel keeps the three phrases in
  // entryWords beside their translations rather than loose in this file.
  // A tour or a card is not a ticket, so At a Glance's Tickets row does not
  // link to one. The line under the buttons still offers it as what it is.
  const bookRow = ticketHref && ticketSellsDoor
    ? { href: ticketHref, label: bookLabel(ticketAgent), note: offerNote, source: bookSource }
    : null;

  // ── AND THE TOUR, WHICH IS A DIFFERENT QUESTION ─────────────────
  //
  // Oliver, 9 Sep 2026: "What do we do about the overlap with Tiqets and
  // GetYourGuide.com?" They mostly do not overlap. Tiqets sells the door,
  // GetYourGuide sells the walk, and Denmark has almost no museum admissions on
  // GetYourGuide because a Danish museum sells its own. So this is a second row
  // rather than a second candidate for the ticket row, and a reader who sees
  // both has been told more rather than asked to choose.
  //
  // isTourUrl rather than a host test written here, for the reason the ticket
  // destination above uses isBookableTicketUrl: one file owns the question of
  // what a link IS, and this file owns what a row looks like.
  //
  // NO VALUE ON THE ROW, and that is deliberate rather than unfinished. The
  // ticket row's value is a price the pipeline drafted; nothing has drafted a
  // sentence about this tour, and composing one here would be inventing a
  // description of somebody else's product. "Tours: On GetYourGuide" is
  // complete and true, and the glance card already renders a link with no value
  // for exactly this case.
  const tourDest = String(item?.tourUrl || "").trim();
  const tourOk = isTourUrl(tourDest);
  const tourHref = tourOk ? (affiliateHref(tourDest) || tourDest) : "";
  const tourRow = tourHref
    ? { href: tourHref, label: "On GetYourGuide", note: affiliateNote(tourDest, lang) }
    : null;
  // ── AND THE SAME COLOUR CANNOT BE BOTH FILL AND INK ─────────────
  //
  // Oliver, 3 Sep 2026: "the pink/purple writing is so uncomfortable for the
  // eyes.. it's fine to have a different color.. but find a better."
  //
  // `color` is a hex the DRAFTING MODEL chose, and this page uses it two ways:
  // as a solid badge behind white text, and as 10-11px bold text on the card.
  // Those want opposite things. A deep magenta is a good badge and an unreadable
  // ink — Jomfru Ane Gade's measured 2.94:1 against its own pill, and the
  // DEFAULT nightlife brown (#5D4037, which most rows carry) measured 1.86:1.
  //
  // So the fill keeps the row's colour and the text takes a version of the same
  // hue lifted to 4.5:1, which is the line theme.js already measures its own
  // colours against. A colour that already clears it comes back untouched.
  //
  // Computed here in the render and never hoisted: C is mutated by applyTheme,
  // so a module-level constant would be measured against whichever theme
  // happened to load first and would be silently wrong in the other two.
  const ink = readableOn(color, C.surface);
  // ── ONE POINT, TWO USES ───────────────────────────────────────────
  // The pin and the dots come from the same resolution, so the map cannot show a
  // pin with no neighbours because the two halves disagreed about where it is.
  // The pools are keyed by the same strings openStopDetail dispatches on.
  const here = detailPoint(item, kind);
  const near = here ? nearbyPublished(here, placedLibrary({
    town: towns,
    event: [...events, ...majorEvents, ...vikingEvents],
    free: freeEntrance,
    food: foodSpots,
    nightlife: nightlifeSpots,
  }, { includeTowns: true }), { maxKm: SAME_VISIT_KM, limit: SAME_VISIT_LIMIT, exclude: item.name }) : [];
  const townEvents = kind === "town" ? eventsForTown(item.name).slice(0, 4) : [];
  const townNearby = kind === "town"
    ? nearbyEvents(item.name, String(item.name || "").trim().toLowerCase())
        .filter(x => x.e.date && (isCurrentlyLive(x.e.date, x.e.dateEnd) || isUpcoming(x.e.date)))
        .slice(0, 3)
    : [];
  return (
    // BUG FIX: z-index was 290, lower than the new pre-build "here's what's
    // coming up" preview screen (guideModal === "preview" in App.jsx, z-index
    // 950) — opening a place's "Read more" from inside that preview would
    // render DetailPage BEHIND it, invisible. Bumped above every modal/overlay
    // z-index used elsewhere in the app (all ≤950) so "drill into a real
    // place's full page" always stacks on top, regardless of what else is open.
    // ── FULL SCREEN, OR A WINDOW OVER WHAT YOU WERE DOING ────────────
    //
    // Oliver, 9 Sep 2026: "If AI mentions it, and the picture pops up.. it
    // should say 'read more' on it. And when you click it, you get a new window
    // popping up. Not a new tab or redirect to the page. But a window that when
    // you click off it, it disappears as if you 'alt-f4' on it."
    //
    // The full-screen version was already not a redirect, but it covered the
    // conversation completely, so coming back meant finding the close button
    // and there was nothing to click OFF onto. A reader who opened Ribe out of
    // curiosity lost the sentence that made them curious.
    //
    // So from the chat it is a window: the page floats in the middle, the chat
    // is visible around it, and the surround closes it. Everywhere else it is
    // what it always was, because a browse screen has nothing behind it worth
    // keeping in view.
    //
    // THE CLOSE IS ON THE BACKDROP AND NOT ON THE PANEL. onClick on this div
    // fires for clicks on its children too, so the panel below stops the event:
    // without that, every press inside the page closes the page.
    <div
      onClick={windowed ? (e) => { if (e.target === e.currentTarget && typeof onClose === "function") onClose(); } : undefined}
      style={windowed
        ? { position: "fixed", inset: 0, background: "rgba(6,9,18,.72)", zIndex: 970, overflowY: "auto", display: "flex", alignItems: "flex-start", justifyContent: "center", padding: "clamp(12px, 4vh, 48px) 16px" }
        : { position: "fixed", inset: 0, background: C.bg, zIndex: 970, overflowY: "auto" }}
    >
    <div
      onClick={windowed ? (e) => e.stopPropagation() : undefined}
      style={windowed
        ? { width: "min(720px, 100%)", maxHeight: "88vh", overflowY: "auto", background: C.bg, borderRadius: 16, border: `1px solid ${C.border}`, boxShadow: "0 24px 60px rgba(0,0,0,.55)" }
        : undefined}
    >
      {/* Collapsed rather than empty: a band with no photograph in it is
          shorter, so it reads as a deliberate marker for the entry rather than
          as a picture that failed to arrive, and the writing starts higher. */}
      <div style={{ height: hasShot ? 190 : 120, background: `${color}22`, display: "flex", alignItems: "center", justifyContent: "center", position: "relative", overflow: "hidden" }}>
        <span style={{ fontSize: 64, opacity: hasShot ? 0.25 : 1, position: hasShot ? "absolute" : "static" }}>{item.emoji}</span>
        {!!String(item?.photo || "").trim() && (
          <img src={item.photo} alt={item.name} referrerPolicy="no-referrer" onError={() => setShotFailed(true)}
            style={{ width: "100%", height: "100%", objectFit: "cover", position: "relative", display: shotFailed ? "none" : "block" }} />
        )}
        <button onClick={onClose}
          style={{ position: "absolute", top: "calc(14px + env(safe-area-inset-top))", left: 14, background: "rgba(10,15,30,0.7)", border: "none", color: "#fff", borderRadius: 100, padding: "8px 14px", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "'Inter', sans-serif" }}>
          ‹ Back
        </button>
        <div style={{ position: "absolute", top: "calc(14px + env(safe-area-inset-top))", right: 14, display: "flex", alignItems: "center", gap: 8 }}>
          {onToggleSave && (
            <button onClick={onToggleSave}
              style={{ background: "rgba(10,15,30,0.75)", backdropFilter: "blur(4px)", border: "none", borderRadius: 100, width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", fontSize: 15, color: isSaved ? "#E91E63" : "#ffffffaa" }}>
              {isSaved ? "♥" : "♡"}
            </button>
          )}
          {item.type && kind !== "food" && <div style={{ background: color, color: "#fff", fontSize: 10, fontWeight: 700, padding: "5px 11px", borderRadius: 100, textTransform: "uppercase" }}>{item.type}</div>}
        </div>
      </div>
      {/* Credit for the hero image, immediately under the photo it belongs to,
          which is what CC BY and CC BY-SA ask for. Renders nothing when
          the image has no credit on file, so it costs nothing on the many photos
          that need none. */}
      {/* __photoCredit is set when the hero came from Wikimedia Commons rather
          than from a file Oliver downloaded, so the attribution travels with the
          entry instead of having to be matched by filename in
          image-credits.json, which only knows about downloaded files. Falls
          back to that lookup when it is absent, which is every older entry. */}
      {/* No credit under a photograph that did not load: it credits nothing,
          and it is the one line that tells a reader the picture is real. */}
      <PhotoCredit photo={hasShot ? item.photo : ""} credit={item.__photoCredit} style={{ padding: "6px 20px 0", maxWidth: 620, margin: "0 auto" }} />
      <div style={{ padding: "14px 20px 40px", maxWidth: 620, margin: "0 auto" }}>
        <div style={{ fontSize: 10, fontWeight: 700, color: ink, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 8 }}>
          {/* A shop and a shopping street both say where they are, which is
              what `location` holds on them. Oliver, 22 Sep 2026. */}
          {kind === "event" ? `${item.town}` : kind === "nightlife" ? item.location : kind === "free" ? item.city : kind === "food" ? item.location : kind === "shop" ? (item.location || item.town) : item.region}
        </div>
        <div style={{ fontSize: 30, fontWeight: 600, fontFamily: "'Fraunces', serif", color: C.text, lineHeight: 1.1, marginBottom: 8 }}>{item.name}</div>

        {/* ── THE ADD-TO-TRIP ROW ─────────────────────────────────────
            The heart in the top corner already did this and had done for
            months. It sits on a photograph, it is 32 pixels across, and it
            carries no label, so the only people who ever pressed it were the
            ones who guessed. See utils/savedTrip.js for the whole argument;
            the short version is that the save loop was finished, wired and
            invisible, which is the exact failure this codebase keeps finding.

            Under the title rather than over the photo: this is a decision about
            the place, so it belongs where the place is being read about, at a
            size a thumb can hit.

            The second button only exists once something is saved, because an
            offer to plan a trip around nothing is the empty-checklist tone
            Oliver objected to. */}
        {/* Not on another country's page yet: the trip it adds to is built by
            the planner, which is Phase 3 of LITHUANIA_PLAN_29SEP.md. */}
        {onToggleSave && activeCountry() === DEFAULT_COUNTRY && (
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
              <button onClick={onToggleSave}
                style={{ background: isSaved ? `${C.gold}1e` : "none", border: `1px solid ${isSaved ? C.gold + "66" : C.border}`, color: isSaved ? C.gold : C.text, borderRadius: 100, padding: "9px 16px", fontSize: 12.5, fontWeight: 700, cursor: "pointer", fontFamily: "'Inter', sans-serif" }}>
                {saveLabel(isSaved)}
              </button>
              {/* ── BEEN, BESIDE SAVE, ANSWERING A DIFFERENT QUESTION ──
                  Oliver, 6 Sep 2026: "if someone has been somewhere, then it'll
                  say on the different places, and it won't include them in a
                  new guide."

                  Save is "I want to go" and this is "I have gone", and
                  somewhere can honestly be both: a bar you loved and want back
                  at is saved AND been. So they are two independent toggles and
                  neither one clears the other.

                  Quieter than Save on purpose. Save is the thing the product is
                  asking you to do; this is bookkeeping, and a second gold pill
                  beside the first would read as two equal calls to action. */}
              {onToggleBeen && (
                <button onClick={onToggleBeen}
                  style={{ background: hasBeen ? `${C.text}12` : "none", border: `1px solid ${hasBeen ? C.text + "44" : C.border}`, color: hasBeen ? C.text : C.muted, borderRadius: 100, padding: "9px 14px", fontSize: 12.5, fontWeight: 700, cursor: "pointer", fontFamily: "'Inter', sans-serif" }}>
                  {hasBeen ? uiT("entry.beenDone", lang) : uiT("entry.been", lang)}
                </button>
              )}
              {isSaved && onPlanFromSaved && planFromSavedLabel(savedCount) && (
                <button onClick={onPlanFromSaved}
                  style={{ background: "none", border: "none", color: C.accent, fontSize: 12.5, fontWeight: 700, cursor: "pointer", padding: "9px 4px", fontFamily: "'Inter', sans-serif" }}>
                  {planFromSavedLabel(savedCount)}
                </button>
              )}
            </div>
            <div style={{ fontSize: 11.5, color: C.muted, marginTop: 7, lineHeight: 1.5 }}>
              {/* What being marked MEANS, because a tick with no consequence is
                  a tick nobody presses twice. It says the thing that
                  happens, and it says the town rule out loud rather than
                  letting somebody find it by marking Copenhagen and watching
                  their trip stay the same. */}
              {hasBeen
                ? (kind === "island"
                    // Same argument as a town, one boat further out: an island
                    // you have been to is still a base and still a destination,
                    // so a guide keeps routing you there and fills the days
                    // with what you did not do.
                    ? "Marked as somewhere you have been. Your guides will still cross to it and still base you here, and will fill the days with things you have not done."
                    : kind === "town"
                    ? "Marked as somewhere you have been. Your guides will still route you here and still base you here, and will fill the days with things you have not done."
                    : "Marked as somewhere you have been. Gemlyx will leave it out of new guides.")
                : saveHint(isSaved, savedCount)}
            </div>
          </div>
        )}

        {kind === "nightlife" && (item.crowd || true) && (
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginBottom: 18 }}>
            {item.crowd && (
              <span style={{ display: "inline-block", fontSize: 11, fontWeight: 700, color: ink, background: `${color}18`, padding: "5px 12px", borderRadius: 100 }}>
                👥 {item.crowd}
              </span>
            )}
            {/* Beside the crowd, because they are the two halves of one
                question: who is in there, and how dressed up are they. Draws
                nothing at all when the row has not said. */}
            <VenueStyleChip item={item} C={C} />
          </div>
        )}
        {kind === "free" && <AttractionBadge item={item} C={C} />}
        {kind === "food" && (
          <div style={{ display: "flex", gap: 10, marginBottom: 18, flexWrap: "wrap" }}>
            <span style={{ fontSize: 11, fontWeight: 700, color: ink, background: `${color}18`, padding: "5px 12px", borderRadius: 100 }}>{item.category}</span>
            <span style={{ fontSize: 11, fontWeight: 700, color: C.gold, background: `${C.gold}18`, padding: "5px 12px", borderRadius: 100 }}>{item.price}</span>
          </div>
        )}

        {(kind === "event" || kind === "town" || kind === "island" || kind === "shop") && item.tier && (
          <div style={{ marginBottom: 12 }}>
            {(() => {
              const t = item.tier.toLowerCase();
              const tierStyle = t.includes("can't miss") || t.includes("cant miss")
                ? { icon: "⭐", label: "Can't Miss Out", color: "#0A0F1E", bg: C.gold }
                : t.includes("highly recommended")
                ? { icon: "👍", label: "Highly Recommended", color: "#4CAF50", bg: "#4CAF5022" }
                : t.includes("worth considering")
                ? { icon: "◷", label: "Worth Considering", color: "#FFB347", bg: "#FFB34722" }
                : t.includes("already nearby")
                ? { icon: "📍", label: "Best If Already Nearby", color: C.muted, bg: `${C.border}44` }
                : { icon: "👍", label: item.tier, color: "#4CAF50", bg: "#4CAF5022" }; // unrecognized value — show it verbatim rather than silently hiding it
              return (
                <span style={{ fontSize: 11, fontWeight: 700, padding: "5px 12px", borderRadius: 100, marginRight: 8, display: "inline-block", marginBottom: 8, color: readableOn(tierStyle.color, C.surface), background: tierStyle.bg }}>
                  {/* ── THE TABLE EXISTED AND NOTHING READ IT, 9 SEP ────
                      entryWords.js has all four of these in Danish and German
                      and has since the entry vocabulary was built. This span
                      printed the English one, so a Dane reading a town or an
                      event met "Can't Miss Out" in gold above prose that was
                      otherwise entirely in Danish, and the translation sat one
                      function call away the whole time.

                      Every other label on this page goes through entryWord:
                      AtAGlanceCard calls it on every glance row. This badge is
                      not a glance row, which is the only reason it was missed.

                      The unrecognised-value branch above passes item.tier
                      through verbatim, and entryWord returns anything it has
                      no entry for unchanged, so that stays exactly as it was. */}
                  {tierStyle.icon} {entryWord(tierStyle.label, lang)}
                </span>
              );
            })()}
          </div>
        )}
        {kind === "event" && (
          <div style={{ marginBottom: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
              {/* A finished edition still has a real page, because the link
                  can be shared or bookmarked and the entry is about
                  a real festival. What it must not do is wear the same live
                  gold as one happening next week. Skanderborg Festival ended
                  on 9 Aug and this line was gold on 12 Aug. */}
              <span style={{ fontSize: 13, color: hasFinished(item) ? C.muted : C.gold, fontWeight: 700 }}>{getEventDate(item.date, item.dateEnd)}</span>
              {hasFinished(item) && (
                <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 0.6, textTransform: "uppercase", color: C.muted, border: `1px solid ${C.border}`, borderRadius: 100, padding: "3px 9px" }}>
                  This edition has finished
                </span>
              )}
              {/* GUARDED, like the other two rating sites (App.jsx 7026 and
                  9561). shapeForLive's festival branch has no `rating` field,
                  and it is the only insert path into gemlyx_content, so
                  item.rating is undefined on EVERY published event and this
                  rendered a lone gold star with nothing after it. React prints
                  undefined as nothing, so there was no error to notice. */}
              {/* ── AND THE STAR WAS NEVER MEASURED ────────────────────
                  3 Sep 2026. The Places FieldMask asks for displayName,
                  formattedAddress, businessStatus, opening hours and websiteUri.
                  It has never asked for `rating` or `userRatingCount`, and no
                  hardcoded data file carries one. So the only source this number
                  ever had was the workshop prompt telling a model to supply "a
                  real rating if found in reviews" — from research that contains
                  no reviews.

                  A gold star beside a name is the strongest confidence signal on
                  the page, and it was the one number on it that nothing checked.
                  That is the rule the whole pipeline is built on, broken in the
                  most visible place: "any specific, checkable fact must come
                  from the search context, never from your own memory."

                  Removed at RENDER, so the rows already carrying one stop
                  showing it without a redraft, and removed from the prompt so
                  no new row invents one. If real ratings are wanted later they
                  come from the FieldMask, and then this can come back with
                  something behind it. */}
              <span style={{ fontSize: 12, color: C.muted }}>{travelLabel(userCoords, item.town, item.travelTime, journeyOrigin)}</span>
            </div>
          </div>
        )}
        {kind === "event" && (
          <AtAGlanceCard lang={lang} rows={[
            // arrivalGlanceRow rather than arrivalRow: the row is earned by the
            // measured walk at the far end, and it says that walk. See the note
            // above ARRIVAL_WALK_LIMIT in utils/journey.js.
            arrivalOrBusRow(item, kind, here),
            { icon: "🎟️", label: "Tickets", value: pricedLine(item.ticketInfo, item), link: bookRow },
            tourRow ? { icon: "🥾", label: "Tours", value: "", link: tourRow } : null,
            // ── "MAKE PEOPLE AWARE" ──────────────────────────────────
            // Oliver, 15 Aug 2026, off a draft with Danish in a reader field:
            // "I wonder if we should make people aware that an event might have
            // a great language barrier."
            //
            // Gemlyx writing Danish at a reader is a defect and is fixed in the
            // pipeline. The EVENT running in Danish is a fact about the event,
            // and smoothing it over would be the dishonest fix. It sits in At a
            // Glance rather than in prose because it is measured, off the
            // organiser's own pages, and because it is what somebody scans for
            // before booking a flight.
            //
            // Absent unless it was measured: no operator page read means no
            // row, not a reassuring one.
            ...(item.__language?.level === "danish-only" && item.__language?.note
              ? [{ icon: "🗣", label: "Language", value: item.__language.note }]
              : []),
            { icon: "⛺", label: "Camping", value: item.camping },
            { icon: "🏡", label: "Accommodation", value: item.accommodationTip },
          ]} />
        )}
        {kind === "town" && (
          <>
            {/* NO ARRIVAL ROW ON A TOWN. See ARRIVAL_TYPES in utils/helpers.js
                for the reasoning: a town is the destination, not a point, so
                "nearest stop" answers a question nobody asked with a value
                measured from whatever coordinate the geocoder picked for the
                middle of it. Suppressed at RENDER rather than only in the
                drafting prompt, because 71 entries were already published with
                the field filled in and a prompt change cannot reach those. */}
            {/* ── WHAT THIS PLACE HANGS OFF ──────────────────────────
                Two different facts that were being flattened into one, per
                Oliver on 8 Aug ("Nyhavn is 'technically' a town, but it is
                within Copenhagen" and "there are also villages in the 'towns'
                that are under other towns"). "Inside Copenhagen" and "base
                yourself in Nordby" are not the same sentence, and running them
                together is how somebody ends up looking for a hotel in a canal.
                relationLine picks whichever applies and says nothing when
                neither does, which is almost every town. */}
            <AtAGlanceCard lang={lang} rows={[
              (() => { const r = relationLine(item); return r ? { icon: r.label === "Inside" ? "◇" : "🧭", label: r.label, value: r.value } : null; })(),
              { icon: "🛏️", label: "Recommended Stay", value: item.recommendedStayGlance },
              { icon: "☀️", label: "Best Time", value: item.bestTimeGlance },
              // ── GUIDED FIRST, SELF-GUIDED UNDER IT ──────────────
              // Oliver, 10 Sep 2026: "The guided tours, keep them. But swap
              // them around.. so guided tour first and then self-guided tour
              // afterwards." A guided walk is what most visitors mean when
              // they think about booking something, and an audio walk is the
              // cheaper alternative you offer once they have seen it.
              tourRow ? { icon: "🥾", label: "Tours", value: "", link: tourRow } : null,
              // Only a TOWN can carry one: wegotripMatch's TOWN_TYPES is
              // ["town"] and says at length why a nightTown row must not, so
              // this is the one card that needs the row.
              audioRow ? { icon: "🎧", label: "Self-guided tour", value: audioSays, link: audioRow } : null,
              { icon: "🏡", label: "Accommodation", value: item.accommodationGlance },
              { icon: "💰", label: "Typical Costs", value: item.typicalCosts },
            ]} />
            {/* ── WHAT YOU CAN DO FROM HERE WITHOUT MOVING HOTEL ─────
                The other half of the partOf/dayTripFrom pair, seen from the
                parent. This is the piece with actual product value in it: "what
                can I reach from Copenhagen without changing hotel" is one of the
                most common real questions a visitor has, and it is the lever
                that gets somebody who only booked Copenhagen to leave
                Copenhagen — which is the whole anti-concentration argument the
                competitor research landed on, with a UI attached.

                Built by scanning the live towns array for entries that name THIS
                place, so it fills itself in as content is published and shows
                nothing at all until something does. Never a hardcoded list. */}
            {(() => {
              // ── THE DAY TRIP LIST IS GONE, AND THE FIELD IS NOT ──
              // Oliver, 9 Aug 2026, after Rudkobing appeared here as a day
              // trip from Copenhagen. It is on Langeland, about two and a half
              // hours each way, and it appeared because its stored
              // dayTripFrom says "Copenhagen".
              //
              // My first answer was three checks on that field: route it at
              // draft time, sweep the published rows, guard the render. All
              // correct, and all of it machinery to babysit a field a human
              // has to keep true forever. His was better: "I'm not even sure
              // if we need to have it."
              //
              // A CURATED RELATIONSHIP FIELD ALWAYS DRIFTS. Somebody decides,
              // per town, what it is a day trip from, and that is right until
              // the day it is not. Deleting the reader-facing list deletes the
              // whole failure mode rather than watching for it, which is the
              // only kind of fix that cannot regress.
              //
              // WHAT STAYS, DELIBERATELY: dayTripFrom itself, as a PLANNER
              // input. It encodes what coordinates cannot, which is whether a
              // place counts as its own stop on a route and whether it has
              // beds. Dragor being close to Copenhagen does not answer that.
              // The field keeps feeding the planner and stops reaching readers.
              //
              // "Inside" survives because it is a different kind of claim.
              // Hellerup being part of Copenhagen is containment, which does
              // not depend on travel time and does not go stale. If the other
              // list is ever missed, bring it back COMPUTED from lat/lon
              // rather than curated: sorted by real distance, Rudkobing at
              // 144 km could never appear in it.
              const inside = areasInside(item.name, towns);
              // Guard narrowed with the cut. Left as it was, a town with no
              // areas inside it but a stale dayTripFrom would render the card
              // border and padding around nothing.
              if (!inside.length) return null;
              const group = (heading, list, note) => (
                <div style={{ marginBottom: 14 }}>
                  <div style={{ fontSize: 10.5, fontWeight: 700, color: C.gold, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 8 }}>{heading}</div>
                  <div style={{ fontSize: 11.5, color: C.muted, lineHeight: 1.6, marginBottom: 9 }}>{note}</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 7 }}>
                    {/* _src IS REQUIRED BELOW, not decoration. App.jsx's
                        openStopDetail dispatches entirely on real._src, and
                        liveContent only stamps that onto the lookup map
                        guideEnrichment builds, never onto the towns array
                        itself. A raw town from this list matched none of its
                        branches, so every one of these buttons would have
                        looked live and done nothing. */}
                    {list.map(t => (
                      <button key={t.id} onClick={() => onOpenNearby && onOpenNearby({ ...t, _src: "town" })}
                        style={{ background: C.surface, border: `1px solid ${C.border}`, color: C.light, borderRadius: 100, padding: "7px 14px", fontSize: 12, fontWeight: 700, cursor: onOpenNearby ? "pointer" : "default", fontFamily: "'Inter', sans-serif" }}>
                        {t.name}
                        <span style={{ color: C.muted, fontWeight: 600 }}> · {kindLabel(t)}</span>
                      </button>
                    ))}
                  </div>
                </div>
              );
              return (
                <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 16, padding: "16px 18px", marginBottom: 18 }}>
                  {group(`Inside ${item.name}`, inside, "Part of the city itself, so you are already there.")}
                </div>
              );
            })()}
            {/* ── AND THE ESSENTIALS THAT ONLY APPLY HERE ────────────
                Oliver, 11 Sep 2026: "we need to input 'essentials' on the blog
                pages. So essentials or tips for Odense. Could be put into the
                Odense Blog."

                Odense Letbane and FynBus Tourist were both sitting on the
                national list, between Rejsekort and MobilePay, because an
                essential row had no field that could say where it applied. See
                utils/essentialPlace.js for why the field is a SCOPE and not a
                town: FynBus is Funen's bus and belongs on four town pages.

                NOTHING RENDERS UNTIL A ROW IS PLACED. Every published row is
                national today, so this block is invisible on every town page
                until somebody types a place into the Studio box, and it stays
                invisible on the towns nothing has been written for. */}
            {(() => {
              const here = essentialsForPlace(essentials, item);
              if (!here.length) return null;
              return (
                <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 16, padding: "16px 18px", marginBottom: 18 }}>
                  <div style={{ fontSize: 10.5, fontWeight: 700, color: C.gold, letterSpacing: 1.2, textTransform: "uppercase", marginBottom: 8 }}>
                    {uiT("entry.localEssentials", lang).replace("{town}", item.name)}
                  </div>
                  <div style={{ fontSize: 11.5, color: C.muted, lineHeight: 1.6, marginBottom: 12 }}>{uiT("entry.localEssentialsNote", lang)}</div>
                  {here.map((row, i) => {
                    // linksOf, not row.link: a merged row carries `links` and
                    // two operators, and reading the singular field on one of
                    // those renders a card with no way out of it.
                    const links = linksOf(row);
                    return (
                      <div key={row.name} style={{ display: "flex", gap: 11, alignItems: "flex-start", paddingTop: i ? 11 : 0, marginTop: i ? 11 : 0, borderTop: i ? `1px solid ${C.border}` : "none" }}>
                        <span style={{ fontSize: 19, lineHeight: 1.3, flexShrink: 0 }}>{row.emoji || "✨"}</span>
                        <div style={{ minWidth: 0 }}>
                          <div style={{ fontSize: 13, fontWeight: 700, color: C.text, display: "flex", alignItems: "center", gap: 7, flexWrap: "wrap" }}>
                            {row.name}
                            {/* WHICH OF THE TWO LISTS, said on the card. An
                                essential is something that costs money or
                                strands you and a tip only makes the trip
                                better, and a reader deciding what to do before
                                a flight needs to know which one this is. */}
                            <span style={{ fontSize: 9, fontWeight: 700, letterSpacing: 0.5, textTransform: "uppercase", color: essentialKindOf(row) === "tip" ? C.muted : C.gold, border: `1px solid ${essentialKindOf(row) === "tip" ? C.border : C.gold}`, borderRadius: 100, padding: "1px 7px" }}>
                              {essentialKindOf(row) === "tip" ? "Tip" : "Essential"}
                            </span>
                          </div>
                          {row.desc && <div style={{ fontSize: 12, color: C.light, lineHeight: 1.6, marginTop: 4 }}>{row.desc}</div>}
                          {row.price && <div style={{ fontSize: 11.5, color: C.muted, marginTop: 4 }}>{row.price}</div>}
                          {/* ── THE SECOND PLACE AN ESSENTIAL IS DRAWN ─────
                              and until 16 Sep 2026 the one that drew a raw href
                              with no disclosure on it. Nothing published today
                              reaches it with a paid link, because a national row
                              never appears on a town page and every paid row is
                              national, so this was one Studio placement away
                              from printing an undisclosed affiliate link rather
                              than an actual bug. The same door as the Essentials
                              card, so it cannot become one. */}
                          {links.length > 0 && (
                            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 7 }}>
                              {links.map(l => {
                                const out = outboundLink(l.url);
                                if (!out.href) return null;
                                return (
                                  <span key={l.url} style={{ display: "inline-flex", flexDirection: "column", gap: 3 }}>
                                    <a href={out.href} target="_blank" rel={`noopener ${out.rel}`}
                                      style={{ fontSize: 11.5, fontWeight: 700, color: C.gold, textDecoration: "none", border: `1px solid ${C.border}`, borderRadius: 100, padding: "5px 11px" }}>
                                      {l.label || uiT("entry.website", lang)} →
                                    </a>
                                    {out.note && <span style={{ fontSize: 10, color: C.muted, lineHeight: 1.5, maxWidth: 260 }}>{out.note}</span>}
                                  </span>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })()}
            {/* ── AND NO HOTEL LINKS HERE, ONLY IN THE GUIDE ─────────
                Oliver, 10 Sep 2026, looking at the three of them on the
                Copenhagen page: "Remove the hotel links. No reason to have
                them. nobody will click the Trip.com and order because of
                this."

                This block was his own ask on 7 Aug, and the reason written
                here was that "the town page is where someone decides they
                want to sleep there". That is true about the DECISION and
                wrong about the act. Deciding you like Copenhagen and booking
                a bed are not the same moment, and the second one needs dates.

                A town page has no dates to send, so all three could ever be
                is a link to somebody's empty search box. GuidePage's day
                cards send Booking a real checkin date and the day's own stay
                area, and read "See 3-4 nights on Booking.com". Same three
                partners, and only one of the two versions knows what it is
                asking for.

                Two of the three earned nothing besides. The note under them
                said so out loud, so the block was three buttons wide and
                needed a line of small print to explain that most of it did
                not pay. See GuidePage for the version that stays. */}
            {/* Hands travelLabel the WHOLE ENTRY, so partOf is visible and
                anywhere inside Copenhagen is not a journey from Copenhagen, and
                renders nothing at all when there is no figure. Dragør's page
                carried a line reading only "from CPH" until this changed. */}
            {/* THE ORIGIN COMES OFF THE ROW, not off this line's assumption.
                Only a town is measured from Copenhagen; everything else is
                measured from its own town centre, and __journey.from is what
                the measurement wrote down. A row with no journey names no
                origin and prints the figure alone. */}
            {travelLabel(userCoords, item, item.travelTime, journeyOrigin) && (
              <div style={{ fontSize: 12, color: C.muted, marginBottom: 18 }}>{travelLabel(userCoords, item, item.travelTime, journeyOrigin)}</div>
            )}

            {/* WHAT'S ON IN THIS TOWN (Oliver's ask, Aug 5 2026: "is it possible to
                show the soon coming events in these towns"). Everything here is a
                real published festival row whose own `town` field names this town.
                Nothing is generated, nothing is inferred from the town's text, and
                if no published festival matches, the section does not render at
                all rather than saying something vague like "check back later". */}
            {/* ── AND FOLDED AWAY UNTIL SOMEBODY WANTS IT ────────────
                Oliver, 10 Sep 2026, on the Copenhagen page: "What's on in
                Copenhagen make it a dropdown link."

                Four event cards is most of a screen, and it sits between the
                At a Glance card and the first sentence about what the place
                is. Somebody reading a town page is deciding whether
                to go at all; what is on in five weeks is a question they ask
                second, if they ask it. The count is on the row so it is still
                answerable without opening it, which is the difference between
                folding something away and hiding it. */}
            {(townEvents.length > 0 || townNearby.length > 0) && (
              <div style={{ marginBottom: 22 }}>
                <button onClick={() => setEventsOpen(o => !o)}
                  style={{ display: "flex", alignItems: "center", gap: 8, width: "100%", textAlign: "left", background: "none", border: "none", padding: 0, marginBottom: eventsOpen ? 10 : 0, cursor: "pointer", fontFamily: "'Inter', sans-serif" }}>
                  <span style={{ fontSize: 10, fontWeight: 700, color: C.gold, letterSpacing: 1.5, textTransform: "uppercase" }}>
                    {townEvents.length > 0 ? `What's on in ${item.name}` : "What's on nearby"}
                  </span>
                  <span style={{ fontSize: 10.5, color: C.muted, fontWeight: 600 }}>
                    {townEvents.length + townNearby.length === 1 ? "1 event" : `${townEvents.length + townNearby.length} events`}
                  </span>
                  <span style={{ fontSize: 11, color: C.muted, marginLeft: "auto", transform: eventsOpen ? "rotate(180deg)" : "none" }}>⌄</span>
                </button>
                {eventsOpen && townEvents.map(e => {
                  const live = isCurrentlyLive(e.date, e.dateEnd);
                  // Was a bare comparison against one string, so "cancelled"
                  // and "off_sale" both fell through to showing ticketInfo as
                  // though nothing were wrong. The badge table decides what a
                  // status is allowed to say, in one place. See utils/tickets.js.
                  // ── AND WHO SAID IT, WHICH THIS LINE NEVER ASKED ────
                  // This rendered ticketBadge().label on its own, in red, with
                  // no tick and no hover: a row reading "Sold out" off a status
                  // that may be nothing but the writer's feeling. The event card
                  // has told the two apart since 13 August and this list could
                  // not. A tick works in a row of chips and not in a one-line
                  // list, so here the words carry it. See ticketLabelLine.
                  const ticket = ticketLabelLine(e);
                  const ticketWarn = ticket.tone === "bad" || ticket.tone === "warn";
                  return (
                    <button key={e.id ?? e.name} onClick={() => onOpenEvent && onOpenEvent(e)} disabled={!onOpenEvent}
                      style={{ display: "flex", alignItems: "center", gap: 12, width: "100%", textAlign: "left", background: C.surface, border: `1px solid ${live ? "#4CAF5066" : C.border}`, borderRadius: 12, padding: "12px 14px", marginBottom: 8, cursor: onOpenEvent ? "pointer" : "default", fontFamily: "'Inter', sans-serif" }}>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 3 }}>
                          {live && (
                            <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 9, fontWeight: 700, color: "#4CAF50", textTransform: "uppercase", letterSpacing: 0.5 }}>
                              <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#4CAF50", boxShadow: "0 0 6px #4CAF50" }} />
                              On now
                            </span>
                          )}
                          <span style={{ fontSize: 14, fontWeight: 700, color: C.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{e.name}</span>
                        </div>
                        <div style={{ fontSize: 11.5, color: C.gold, fontWeight: 600 }}>
                          {getEventDate(e.date, e.dateEnd)}
                          {e.type ? <span style={{ color: C.muted, fontWeight: 400 }}> · {e.type}</span> : null}
                        </div>
                        {/* Ticket reality carried through verbatim from the published
                            row. A sold-out festival that reads as a plan is the single
                            most expensive way to mislead someone about a trip. */}
                        {ticketWarn ? (
                          <div title={ticketProvenance(e)} style={{ fontSize: 11, color: ticket.tone === "bad" ? "#FF8A80" : "#FFB347", fontWeight: 600, marginTop: 3, opacity: ticket.checked ? 1 : 0.8 }}>{ticket.label}</div>
                        ) : e.ticketInfo ? (
                          <div style={{ fontSize: 11, color: C.muted, marginTop: 3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{e.ticketInfo}</div>
                        ) : null}
                      </div>
                      {onOpenEvent && <span style={{ fontSize: 14, color: C.muted, flexShrink: 0 }}>›</span>}
                    </button>
                  );
                })}

                {eventsOpen && townNearby.length > 0 && (
                  <>
                    <div style={{ fontSize: 10, fontWeight: 700, color: C.muted, letterSpacing: 1.5, textTransform: "uppercase", margin: `${townEvents.length > 0 ? 16 : 0}px 0 10px` }}>
                      Nearby, worth knowing about
                    </div>
                    {townNearby.map(({ e, km }) => (
                      <button key={`near-${e.id ?? e.name}`} onClick={() => onOpenEvent && onOpenEvent(e)} disabled={!onOpenEvent}
                        style={{ display: "flex", alignItems: "center", gap: 12, width: "100%", textAlign: "left", background: "transparent", border: `1px solid ${C.border}`, borderRadius: 12, padding: "11px 14px", marginBottom: 8, cursor: onOpenEvent ? "pointer" : "default", fontFamily: "'Inter', sans-serif" }}>
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: 13.5, fontWeight: 700, color: C.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", marginBottom: 3 }}>{e.name}</div>
                          <div style={{ fontSize: 11.5, color: C.muted }}>
                            <span style={{ color: C.gold, fontWeight: 600 }}>{getEventDate(e.date, e.dateEnd)}</span>
                            {" · "}{e.town}, about {km < 10 ? km.toFixed(1) : Math.round(km)} km away
                          </div>
                        </div>
                        {onOpenEvent && <span style={{ fontSize: 14, color: C.muted, flexShrink: 0 }}>›</span>}
                      </button>
                    ))}
                    <div style={{ fontSize: 10.5, color: C.muted, lineHeight: 1.5 }}>
                      Distances are straight line between town centres, not driving time.
                    </div>
                  </>
                )}
              </div>
            )}
          </>
        )}
        {(kind === "free" || kind === "attraction") && (
          <AtAGlanceCard lang={lang} rows={[
            { icon: "🎟️", label: "Tickets", value: pricedLine(item.ticketsGlance, item), link: bookRow },
            /* ── AND NOW NOT ON ATTRACTIONS EITHER ────────────────────
               Oliver, 19 Aug 2026: "I think we should get rid of
               'time-needed'."

               This is the food decision of 17 August finishing its job. The
               reason given there applied to every type and was only acted on
               for one: the number never came from research. Whatever the writer
               estimated was overwritten at publish by stayDurationForCategory,
               which returned ONE OF THREE CONSTANTS chosen by a regex over a
               category word — "2 to 3 hours" for anything matching museum or
               castle, "30 to 45 mins" for anything matching park or square,
               "1 to 2 hours" for everything else. So a deer park the size of a
               suburb and a bandstand both read 30 to 45 mins, and neither figure
               was measured, sourced or checked by anybody.

               On a product whose entire claim is that nothing is printed that
               nobody checked, a row wearing a clock icon and stating a duration
               is the most confident-looking unsourced thing on the card.
               It is gone at the reader, at the writer and at the schema. */
            { icon: "💰", label: "Extra Costs", value: item.extraCosts },
            { icon: "♿", label: "Accessibility", value: item.accessibility },
            arrivalOrBusRow(item, kind, here),
          ]} />
        )}
        {/* ── NO TIME NEEDED ON FOOD ────────────────────────────────
            Oliver, 17 Aug 2026: "At food, let's get rid of the 'time needed'
            section.. it's stupid tbh."

            The row read item.timeNeeded, and that value never came from research:
            stayDurationForCategory overwrote the writer's own estimate with one of
            four constants keyed off a word in the category, and every food street
            in the country received the same one. Removed HERE as well as at the
            three write sites, because a published row keeps whatever it was
            published with. The field stays harmlessly in old payloads and stops
            reaching a reader today, rather than after a re-draft of every entry.

            Restaurants and markets both, since for a market the figure was a
            single nationwide constant and said even less than the guess. */}
        {/* ── THE ISLAND, WHOSE At a Glance LEADS WITH THE CROSSING ──
            The order of these rows is the order the questions get asked. On a
            town page the first question is where it sits; on an island it is
            how you get on and off it, and whether that changes in November.

            NO ARRIVAL ROW, for the same reason a town has none: nearestStation
            is carried on the row and is the measured arrival point, which on an
            island is usually the berth the ferry lands at, and printing "nearest
            stop: Ballen Havn" on the page about Ballen's own island answers
            nothing. See ARRIVAL_TYPES in utils/helpers.js.

            EVERY ROW IS ITS OWN FIELD AND RENDERS ONLY WHEN FILLED. An island
            drafted without the operator's page in front of it prints no
            crossing at all, which is the honest result. AtAGlanceCard drops a
            row with an empty value. */}
        {kind === "island" && (
          <>
            <AtAGlanceCard lang={lang} rows={[
              // A fixed link outranks a ferry, because if you can drive there
              // the sailing time is not the answer to "how do I get there".
              item.fixedLink ? { icon: "\u2500", label: "Fixed link", value: item.fixedLink } : null,
              item.crossingGlance ? { icon: "\u26f4", label: "Crossing", value: item.crossingGlance } : null,
              // ── AND THE OPERATOR IS A DOOR, NOT A NAME ────────────
              //
              // Oliver, 20 Sep 2026: "sejerø færgen has to be gone through when
              // sejerø is put on the guide", and on what it should be, "like
              // its website".
              //
              // Counted over the 15 published islands before this was written:
              // every one named its operator and not one could send you to it.
              // The timetable and the booking are both behind that link and
              // both change by season, so the operator's own page is the only
              // one that is right today. Validated on the way in, because a
              // tourist board's copy of last season's timetable is what a
              // search returns first. See utils/ferryDoor.js.
              // ── AND FOUR OF THEM COME FROM THE TIMETABLE ──────────
              //
              // 20 Sep 2026. Rejseplanen's open feed carries Samsø, Bornholm,
              // Ærø and Læsø with the operator's own address attached, so
              // those four get a door without anybody researching one. The
              // row's own link still wins where there is one.
              //
              // THE CREDIT RIDES WITH IT, and it is a licence term rather than
              // manners: the data is CC BY 4.0 and the licence asks for the
              // source named wherever it reaches a reader. See
              // data/ferryRoutes.js.
              (() => {
                if (!item.ferryOperator) return null;
                const door = ferryUrlOf(item);
                if (!door.url) return { icon: "\ud83c\udfe2", label: "Operator", value: item.ferryOperator };
                return { icon: "\ud83c\udfe2", label: "Operator", value: item.ferryOperator,
                         link: { href: door.url, label: FERRY_DOOR_LABEL(item.ferryOperator), note: door.credit } };
              })(),
              // ── AND WHEN THERE IS NO WAY THROUGH AT ALL ───────────
              // An island with no bridge and no operator link cannot answer the
              // first question anybody asks about it. Said plainly rather than
              // left as a gap, because a reader who cannot see the gap assumes
              // there is nothing to book.
              !hasFerryDoor(item)
                ? { icon: "\u26f5", label: "Getting there", value: "The operator's own page is not on file yet, so check the crossing before you plan a day around it." }
                : null,
              // Both ends, never one: a single port name is not usable, because
              // Danish islands are commonly served from two or three mainland
              // harbours and which one you want depends on where you started.
              //
              // AND ONLY WHEN THE LINE ABOVE HAS NOT ALREADY SAID IT. A
              // crossingGlance reading "Kalundborg to Ballen, about 1h" over a
              // Ports row reading "Kalundborg to Ballen" is the same fact
              // printed twice, which reads as two facts. The row earns its
              // place when the ports are known and the one-line summary is not.
              (!item.crossingGlance && item.ferryFrom && item.ferryTo) ? { icon: "\u2693", label: "Ports", value: `${item.ferryFrom} to ${item.ferryTo}` } : null,
              item.offSeasonGlance ? { icon: "\u2744\ufe0f", label: "Off season", value: item.offSeasonGlance } : null,
              { icon: "\ud83d\udecf\ufe0f", label: "Recommended Stay", value: item.recommendedStayGlance },
              { icon: "\u2600\ufe0f", label: "Best Time", value: item.bestTimeGlance },
              { icon: "\ud83c\udfe8", label: "Accommodation", value: item.accommodationGlance },
              { icon: "\ud83d\udcb0", label: "Typical Costs", value: item.typicalCosts },
            ].filter(Boolean)} />
            {item.highlight && (
              <div style={{ background: `${C.gold}10`, border: `1px solid ${C.gold}33`, borderRadius: 14, padding: "14px 16px", marginBottom: 18 }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: C.gold, letterSpacing: 1.4, textTransform: "uppercase", marginBottom: 6 }}>The one thing</div>
                <div style={{ fontSize: 13.5, color: C.text, lineHeight: 1.65 }}>{item.highlight}</div>
              </div>
            )}
          </>
        )}

        {kind === "food" && (
          <AtAGlanceCard lang={lang} rows={[
            { icon: "🍽️", label: "Serves", value: item.category },
            { icon: "💰", label: "Price", value: item.price, link: bookRow },
            { icon: "📍", label: "Neighbourhood", value: item.location },
            // The local bus where the city publishes one (Klaipėda). Danish
            // food and nightlife rows never carried an arrival row, and still
            // do not: busStopRow is null outside the feed's area.
            busStopRow(here),
            tourRow ? { icon: "🥾", label: "Tours", value: "", link: tourRow } : null,
          ]} />
        )}
        {/* ── "WHERE ARE THE PRICES?" ──────────────────────────────
            Oliver, 15 Aug 2026, reading a finished draft for a concert hall.
            Every other place type had a price row on this card and nightlife
            had none, because the night schema had no price field at all: not
            what a beer costs in a bar, not what a ticket costs at a venue that
            sells them. AtAGlanceCard drops a row whose value is empty, so a
            venue whose research had no figure looks exactly as it
            did before, and the ones that did stop hiding it. */}
        {kind === "nightlife" && (
          <AtAGlanceCard lang={lang} rows={[
            { icon: "👥", label: "Crowd", value: item.crowd },
            { icon: "🍺", label: "Type", value: item.category },
            { icon: "💰", label: "What it costs", value: item.priceNote, link: bookRow },
            { icon: "📍", label: "Neighbourhood", value: item.location },
            // The local bus where the city publishes one (Klaipėda). Danish
            // food and nightlife rows never carried an arrival row, and still
            // do not: busStopRow is null outside the feed's area.
            busStopRow(here),
            tourRow ? { icon: "🥾", label: "Tours", value: "", link: tourRow } : null,
          ]} />
        )}
        {item.gemlyxFind && <GemlyxFindCard text={item.gemlyxFind} />}

        <div style={{ fontSize: 14, color: C.light, lineHeight: 1.75, marginBottom: 20 }}>{item.desc}</div>

        {/* ARTICLE LAYOUT (Oliver: "Instead of all of them just being flushed to
            the bottom.. Perhaps at the side (on PC atleast)"). Images used to
            stack full width in document order, so on a wide screen every photo
            was a full-bleed interruption. At 760px and up an image now floats to
            an alternating side at 44% and the prose wraps around it, which is
            how an article reads. Below that width nothing changes: on a
            phone a floated image would squeeze the text into an unreadable
            column. The float is cleared after the body so the next section
            cannot ride up beside a tall photo. */}
        {/* ── THE FIGURE HAS TO OWN A HEIGHT BEFORE THE PICTURE ARRIVES ──
            Oliver, 21 Aug 2026, screenshotting the Christmas-fair page: "jeesus".
            Three photographs, one tall and two collapsed into overlapping
            slivers of caption text at odd offsets down the left edge.

            Nothing was overlapping. Two of the three images had never
            loaded: they carry loading="lazy", they were below the fold, and an
            <img> that has not loaded, has no width or height attribute and no
            CSS aspect ratio reports a height of ZERO. So each unloaded figure
            was a 42px box containing nothing but its own caption, and the floats
            packed themselves around a 383px-tall neighbour exactly as the spec
            says they must. Scrolling down then loaded the pictures and reflowed
            the lot, which is why it looked like it was falling apart live.

            aspect-ratio fixes it before the network is involved: the box is the
            right size from the first paint, the images load into space already
            reserved, and nothing moves. The width and height of the file are not
            stored on the block (studioContent writes src, credit and caption and
            nothing else), so the ratio cannot be the picture's own and has to be
            a house one, with object-fit doing the fitting. That is the same
            bargain PhotoPlate already takes everywhere else in the app.

            Set here rather than inline because these are the only figure rules
            in the file and they belong together. The inline style on the img is
            careful not to name width, aspect-ratio or object-fit, or it would
            win and this would silently do nothing. */}
        <style>{`
          /* CONTAIN, NOT COVER. The first version cropped every figure into a
             landscape box, which loses roughly 44% of a 2:3 event poster, top
             and bottom. Oliver has already made exactly that complaint once, on
             the guide's own stop photos: "avoid the horizontal pictures, you
             can't see the whole castle." Recreating it on the article side would
             have been the same mistake in a new file, and the video in this same
             layout was already using contain, so the two disagreed as well.

             The box is still reserved, which is the whole point of the ratio:
             the height exists before the network answers, nothing collapses, and
             nothing reflows. Contain only changes what happens INSIDE the box,
             and a letterboxed picture on a themed background is a smaller cost
             than a cropped one. */
          .gx-fig img {
            width: 100%;
            aspect-ratio: 4 / 3;
            object-fit: contain;
            background: ${C.surface};
          }
          /* clear: a figure starts below the last figure on ITS OWN side, so the
             two sides read as two columns. Without it a float only has to clear
             the line it lands on, so a figure one caption-line shorter than its
             neighbour lets the next one wedge in at an offset partway across the
             page. That is the stair-step in the screenshot, and it survived
             fixing the heights: measured in a browser, three consecutive figures
             still stepped in to x=258 in a 620px column. */
          @media (min-width: 760px) {
            .gx-fig-right { float: right; clear: right; width: 44%; margin: 4px 0 16px 22px; }
            .gx-fig-left  { float: left;  clear: left;  width: 44%; margin: 4px 22px 16px 0; }
          }
          /* ── AND THE ONE BLOCK THAT CANNOT REFLOW ──────────────────
             Oliver, 6 Sep 2026, on /#/town/copenhagen: "the instagram reel here
             is completely hidden inbetween an image."

             Measured in his browser rather than guessed. That page's body ends

               … 7 prose · 8 figure(right) · 9 INSTAGRAM

             and the embed's own element carries no class, so it had no float
             and no clear while the figure beside it floated right at 44%. The
             embed was being laid out in the channel left over.

             PROSE IS SUPPOSED TO DO THAT. Text wrapping around a picture is the
             whole point of the float, and a paragraph, a heading and a bullet
             list all reflow into whatever width is left. An Instagram embed
             does not: it is a fixed media card holding an iframe with a minimum
             width of its own, so a 56% channel either squeezes it or clips it,
             and on a phone-width column there is no channel at all.

             So it clears both sides, which is the same thing ::after below does
             for the end of the body — and the reason the bug existed is that
             ::after runs AFTER the embed, making the last block the one block
             guaranteed to land beside the last picture. */
          .gx-embed { clear: both; }
          .gx-body::after { content: ""; display: block; clear: both; }
        `}</style>
        {item.blogBody && item.blogBody.length > 0 && (
          <div className="gx-body" style={{ marginBottom: 24 }}>
            {/* withLiveReels BEFORE layoutBody, not after: layoutBody counts
                figures and alternates their sides, so a reel left in the list
                and drawn as nothing would still take a side and leave a hole
                in the text. See utils/reelGate.js. */}
            {layoutBody(withLiveReels(item.blogBody)).map((block, i) => (
              block.type === "bullets" ? (
                <ul key={i} style={{ margin: "0 0 16px", paddingLeft: 20, color: C.light, fontSize: 14, lineHeight: 1.75 }}>
                  {block.items.map((it, j) => <li key={j} style={{ marginBottom: 4 }}>{it}</li>)}
                </ul>
              ) : block.type === "instagram" ? (
                // Wrapped rather than given the class inside InstagramEmbed:
                // that component is also rendered by BlogBody.jsx on the
                // nightlife-town page, which has no floats and no .gx-body, and
                // a clear it does not need is a rule that reads as required.
                <div key={i} className="gx-embed">
                  <InstagramEmbed url={block.url} />
                </div>
              ) : block.type === "video" ? (
                <div key={i} className={`gx-fig gx-fig-${block._side || "right"}`} style={{ marginBottom: 16 }}>
                  <video src={block.src} controls playsInline preload="metadata" style={{ width: "100%", aspectRatio: "4 / 3", objectFit: "contain", borderRadius: 14, display: "block", background: "#000" }} />
                  {/* SAME RULES AS AN IMAGE. layoutBody counts a video as a
                      figure and shares one `seen` set across both, so a video
                      was being given a _showCaption it then ignored, and a video
                      carrying the "- Flickr - <name>" tail printed the credit
                      twice. Found by an adversarial review on 22 Aug: the two
                      branches of one ternary disagreeing about what a caption
                      is. */}
                  {block._showCaption !== false && trimCaption(block.caption) && (
                    <div style={{ fontSize: 11, color: C.muted, marginTop: 6, fontStyle: "italic" }}>{trimCaption(block.caption)}</div>
                  )}
                </div>
              ) : block.type === "image" ? (
                <div key={i} className={`gx-fig gx-fig-${block._side || "right"}`} style={{ marginBottom: 16 }}>
                  {/* referrerPolicy matters for Wikimedia-hosted images: some
                      CDNs refuse a hotlink based on the Referer header, and a
                      refused image is invisible because of the onError below.
                      Sending no referrer is what Wikimedia's own guidance says. */}
                  {/* THE WHOLE FIGURE GOES, not just the picture. Hiding the img
                      alone left its caption and its credit behind, floating in a
                      box with nothing above them, which is half of what the
                      broken screenshot was showing. A credit is attribution FOR A
                      DISPLAYED WORK; with nothing displayed there is nothing to
                      attribute, so removing it with the picture is also the
                      correct reading of the licence and not a shortcut. */}
                  <img src={block.src} alt={trimCaption(block.caption) || item.name} referrerPolicy="no-referrer" loading="lazy"
                    onError={e => { const fig = e.target.closest(".gx-fig"); if (fig) fig.style.display = "none"; else e.target.style.display = "none"; }}
                    style={{ borderRadius: 14, display: "block" }} />
                  {/* _showCaption is false on the second file that carries an
                      identical caption. The credit below is NOT conditional on
                      it: two different photographs need two attributions however
                      alike their titles. See utils/articleLayout.js. */}
                  {block._showCaption !== false && trimCaption(block.caption) && (
                    <div style={{ fontSize: 11, color: C.muted, marginTop: 6, fontStyle: "italic" }}>{trimCaption(block.caption)}</div>
                  )}
                  <PhotoCredit photo={block.src} credit={block.credit} style={{ marginTop: 4 }} />
                </div>
              ) : block.type === "heading" ? (
                <div key={i} style={{ fontSize: 18, fontWeight: 700, color: C.text, fontFamily: "'Fraunces', serif", marginTop: 20, marginBottom: 10 }}>{entryWord(block.content, lang)}</div>
              ) : (
                <div key={i} style={{ fontSize: 14, color: C.light, lineHeight: 1.8, marginBottom: 14 }}>{block.content}</div>
              )
            ))}
          </div>
        )}

        {/* The provenance block. Renders only where there is real provenance
            to show, so an entry with nothing behind it gets no badge at all.
            Placed directly under the article, where someone who has just read a
            claim is standing when they wonder where it came from. */}
        <HowWeKnow item={item} />

        {/* ── AND HOW YOU GET THERE, WHICH WAS MEASURED AND NEVER SHOWN ──
            Oliver, 16 Aug 2026, asking what the page needs. Every entry drafted
            since 13 August carries a full measured itinerary from Copenhagen and
            nothing has ever rendered it. See JourneyCard for what was sitting in
            the database, and utils/journey.js for why every figure in it names
            what it measures.

            Placed between the provenance block and the map: what it is, where
            the claims came from, how to reach it, then where it sits. It renders
            nothing at all on an entry with no measured journey or no date on
            one, which today is every row published before 13 August. */}
        {/* ── AND ONLY WHERE THE JOURNEY ANSWERS A QUESTION ──────────
            Oliver, 3 Sep 2026: "I don't think bar streets should have distance
            from Copenhagen. Only towns should." He is right — nobody travels
            from Copenhagen to Jomfru Ane Gade, they are already in Aalborg —
            and two of his bar streets had shipped with a Copenhagen Metro leg
            on them for streets in Odense and Aarhus.

            GATED HERE AS WELL AS AT THE MEASUREMENT, because the wrong journeys
            are already in Supabase. This file has settled that argument twice:
            "suppressing it at RENDER so all 71 published entries were fixed at
            once rather than needing 71 redrafts." journeyScope has the whole
            rule, including why an attraction is measured from its own town. */}
        {showsJourneyForKind(kind) && <JourneyCard item={item} kind={kind} />}

        {/* Where this is, and what else is around it. Renders only
            when the entry carries real coordinates; TOWN_COORDS is the fallback
            for towns published before __lat/__lon was stored. Coordinates are
            now written for every content type, so entries drafted from PASS 73
            onward get a map too, and older ones once the Studio backfill has
            been run. */}
        <PlaceMiniMap
          lat={here?.lat}
          lon={here?.lon}
          name={item.name}
          color={color}
          neighbours={near}
          // openStopDetail dispatches on _src, so the neighbour is handed
          // over carrying the pool it came from. `row` is the original entry;
          // the rest of the neighbour object is the flattened copy the map draws.
          onOpenNeighbour={(n) => onOpenNearby?.({ ...n.row, _src: n.kind })}
          branches={branchPoints(item)}
        />

        {/* ── AND EVERY ADDRESS, IN WORDS ─────────────────────────────
            Oliver, 7 Sep 2026: "Bones is an example of a restaurant with
            multiple locations." Pins are how you find the nearest one on a map;
            this is how you find it when you already know your town, which is
            what a reader planning a day is doing.

            A branch with no coordinate still gets a line here and no pin. It is
            a real branch: knowing there is a Nørresundby one without knowing
            where it is beats pretending it does not exist, and it is also the
            state every branch starts in before anything geocodes it.

            Renders on two branches, never on one. "1 location" under every card
            in the app is a sentence that says nothing. */}
        {hasBranches(item) && (
          <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14, padding: "16px", marginBottom: 22 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.gold, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 8 }}>📍 {uiT("entry.branches", lang)}</div>
            <div style={{ fontSize: 12.5, color: C.muted, lineHeight: 1.6, marginBottom: 10 }}>{branchLine(item)}</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
              {branchesOf(item).map((b, i) => (
                <div key={`${b.town}-${b.address}-${i}`} style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
                  <div style={{ fontSize: 13, color: C.text, lineHeight: 1.55, minWidth: 0 }}>
                    {b.town && <b>{b.town}</b>}
                    {b.town && b.address ? " · " : ""}
                    {b.address}
                    {b.hours && <div style={{ fontSize: 11.5, color: C.muted, marginTop: 2 }}>{b.hours}</div>}
                  </div>
                  {/* The same destination string the single-address button
                      below uses, per branch, so "take me there" means the one
                      the reader picked rather than whichever got geocoded. */}
                  <a href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(`${item.name} ${branchLabel(b)} Denmark`)}`}
                    target="_blank" rel="noreferrer"
                    style={{ fontSize: 11.5, fontWeight: 700, color: C.gold, textDecoration: "none", flexShrink: 0 }}>
                    Directions ↗
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}

        {kind === "town" && item.highlight && (
          <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 14, padding: "16px", marginBottom: 22 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: C.gold, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 8 }}>◆ {uiT("entry.find", lang)}</div>
            <div style={{ fontSize: 13, color: C.text, lineHeight: 1.65 }}>{item.highlight}</div>
          </div>
        )}
        {kind === "event" && item.tags && (
          <div style={{ display: "flex", gap: 7, flexWrap: "wrap", marginBottom: 26 }}>
            {item.tags.map(t => <span key={t} style={{ fontSize: 12, color: C.text, background: C.surface, border: `1px solid ${C.border}`, padding: "7px 13px", borderRadius: 100 }}>{t}</span>)}
          </div>
        )}
        {(kind === "nightlife" || kind === "food") && item.tip && (
          <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "12px 14px", marginBottom: 22, fontSize: 13, color: C.text, lineHeight: 1.6 }}>
            💡 {item.tip}
          </div>
        )}

        <button onClick={() => checkLiveInfo(item)} disabled={liveInfoLoading === item.name}
          style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 6, width: "100%", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 12, padding: "12px", fontSize: 13, fontWeight: 700, color: C.text, cursor: "pointer", fontFamily: "'Inter', sans-serif", marginBottom: liveInfo?.[item.name] ? 12 : 14 }}>
          {liveInfoLoading === item.name ? uiT("entry.checking", lang) : `🔍 ${uiT("entry.liveInfo", lang)}`}
        </button>
        {liveInfo?.[item.name] && (
          <div style={{ background: `${color}18`, border: `1px solid ${color}`, borderRadius: 12, padding: "12px 14px", marginBottom: 14, fontSize: 13, color: C.text, lineHeight: 1.6 }}>
            {liveInfo[item.name]}
          </div>
        )}

        {/* externalHref, not item.website: seven live festivals store a bare
            domain, which a browser resolves against THIS page and turns into a
            link back to Gemlyx. It returns null for anything that is not a
            plausible http(s) target, so a junk value now renders no button at
            all rather than a button that goes nowhere. */}
        {/* ── AND IF IT IS A TICKETMASTER LINK, IT IS TRACKED ────────
            Oliver, 13 Aug 2026: "let's finish the ticketmaster affiliate."

            ticketmasterUrl returns the ORIGINAL url untouched for every other
            host, which is most of them: Gemlyx links out to madbillet,
            billetto, billetexpressen, kultunaut and whichever agent an operator
            uses, and wrapping one of those in a Ticketmaster tracking URL would
            send a reader somewhere they did not choose and bill a network for a
            click it did not earn.

            The disclosure is empty for those same links rather than being a
            blanket sentence, because "this may earn us a commission" printed
            over a link that earns nothing is a false statement about money.

            rel gains sponsored and nofollow when it IS tracked. That is what
            Google asks for on a paid link, and it is the difference between an
            affiliate programme and something that reads as an undisclosed ad. */}
        {/* ── THE GEMLYX OFFER ────────────────────────────────────
            Oliver, 24 Aug 2026, on who sees what: "it will only be visible to
            paid users. So Gemlyx offer will say 'Only for paying users'. But
            only paying users will know what the offer is."

            Three states, and offerView owns which one this is rather than the
            ternaries below, so the rule can be asserted without a browser and
            cannot quietly become two states the next time this JSX is edited.
            Same argument that moved layoutBody and the food facets out of their
            render sites.

            AN ENDED OFFER RENDERS NOTHING AT ALL, not even the locked badge,
            which is why this asks offerView rather than asking whether __offer
            exists. A badge advertising an offer that has finished would be
            shown to exactly the people being asked to pay for access to it.

            OFFER_NOTE is not decoration. affiliates.js holds the invariant that
            nothing comes out tracked without a sentence under it; this is the
            same question with the money running the other way, since Gemlyx may
            have paid the shop to put the offer there. */}
        {(() => {
          const view = offerView(item.__offer, { paid });
          if (!view.show) return null;
          return (
            <div style={{ background: `${C.gold}14`, border: `1px solid ${C.gold}55`, borderRadius: 12, padding: "12px 14px", marginBottom: 10 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: C.gold, letterSpacing: 0.4, marginBottom: view.locked ? 3 : 5 }}>
                ◈ {OFFER_LOCKED_LABEL}
              </div>
              <div style={{ fontSize: view.locked ? 12 : 13, color: view.locked ? C.muted : C.text, lineHeight: 1.55 }}>
                {view.locked ? OFFER_LOCKED_NOTE : view.text}
              </div>
              <div style={{ fontSize: 10, color: C.muted, lineHeight: 1.5, marginTop: 7 }}>
                {OFFER_NOTE}{view.until ? ` Until ${view.until}.` : ""}
              </div>
            </div>
          );
        })()}

        {!showTicketPair && (kind === "free" || kind === "event") && externalHref(item.website) && !isResellerUrl(externalHref(item.website)) && (() => {
          const dest = externalHref(item.website);
          // affiliateHref rather than ticketmasterUrl: one door, so the day a
          // programme is approved every entry ever published starts earning
          // through it with no republish, and a website that happens to be a
          // Tiqets page is covered too. See utils/affiliates.js.
          const href = affiliateHref(dest) || dest;
          const paid = href !== dest;
          const note = affiliateNote(dest, lang);
          return (
            <div style={{ marginBottom: 10 }}>
              <a href={href} target="_blank" rel={paid ? "noreferrer sponsored nofollow" : "noreferrer"}
                style={{ display: "block", textAlign: "center", background: C.surface, border: `1px solid ${C.border}`, color: C.light, borderRadius: 12, padding: "13px", fontSize: 13, fontWeight: 700, textDecoration: "none" }}>
                🌐 {uiT("entry.website", lang)}
              </a>
              {note && (
                <div style={{ fontSize: 10.5, color: C.muted, lineHeight: 1.5, marginTop: 5, textAlign: "center" }}>{note}</div>
              )}
            </div>
          );
        })()}

        {/* ── AND A TICKET, WHERE ONE EXISTS ────────────────
            Oliver, 15 Aug 2026: "if I add on a Copenhagen attraction, then
            it'll automatically put in the affiliate."

            EVERY CONTENT TYPE, not just free and event above. A workshop, a
            town's own attraction pass and a festival can all have a Tiqets
            page, and restricting this the way the website button is restricted
            would mean the field silently does nothing on the types nobody
            thought about.

            ABSENT, NOT DEGRADED, when there is no ticketUrl. A Tickets button
            falling back to a Tiqets search is the failure Oliver named on the
            preview screen the same morning, "don't put up a bunch of random
            attractions just to have something", except this one asks a reader
            for money. shapeForLive refuses to store anything that is not a
            bookable Tiqets page, so an empty field means there is
            not one.

            The stored value is the PLAIN Tiqets URL and the tracking is added
            here, at render, from the template in config.js. That is what lets
            the marker change without a database migration. */}
        {(() => {
          // ── AND THE ONE ALREADY ON THE ROW ───────────────────────
          //
          // Oliver, 23 Aug 2026: "I have Koge festuge and Copenhell without
          // affiliate links.. is it possible to put in affiliate links on
          // these?"
          //
          // Without republishing either of them, yes. stampTicketSource has
          // written __ticket.url onto the payload since 13 August whenever the
          // Ticketmaster match was STRONG, and shapeForLive keeps it on the
          // live row. So the listing for an event drafted weeks ago is already
          // in Supabase, and nothing had ever read it here.
          //
          // ticketUrl still wins, because that is the field a person can
          // correct by hand. This is the fallback under it, and it goes through
          // the same refusals: a front page or a search never becomes a button.
          const dest = ticketDest;
          // ── EITHER AGENT, EACH THROUGH ITS OWN TEMPLATE ──────────
          // This read isTiqetsProductUrl and tiqetsUrl only, so a stored
          // Ticketmaster event page would have rendered nothing at all. The
          // agent decides which template wraps it, and an unrecognised value
          // still renders no button rather than a bare link asking for money.
          if (!ticketAgent) return null;
          const href = ticketHref;
          const note = offerNote;
          // ── BOTH, SIDE BY SIDE ───────────────────────────────────
          // The reader decides. The line under the pair is the reason to
          // pick the partner, and only when its ticket page gives one. See
          // partnerReason in utils/ticketOffer.js.
          if (showTicketPair) {
            const siteDest = externalHref(item.website);
            const siteHref = affiliateHref(siteDest) || siteDest;
            const sitePaid = siteHref !== siteDest;
            const siteHost = (() => { try { return new URL(siteDest).hostname.replace(/^www\./, ""); } catch { return officialSiteLabel(lang); } })();
            const reason = partnerReason(ticketOffer, { lang });
            const pairBtn = { flex: 1, minWidth: 0, display: "block", textAlign: "center", background: C.surface, borderRadius: 12, padding: "13px 8px", fontSize: 13, fontWeight: 700, textDecoration: "none", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" };
            return (
              <div data-testid="ticket-pair" style={{ marginBottom: 10 }}>
                <div style={{ display: "flex", gap: 8 }}>
                  <a href={siteHref} target="_blank" rel={sitePaid ? "noreferrer sponsored nofollow" : "noreferrer"} title={officialSiteLabel(lang)}
                    style={{ ...pairBtn, border: `1px solid ${C.border}`, color: C.light }}>
                    🌐 {siteHost}
                  </a>
                  <a href={href} target="_blank" rel={note ? "noreferrer sponsored nofollow" : "noreferrer"}
                    style={{ ...pairBtn, border: `1px solid ${C.gold}55`, color: C.gold }}>
                    🎫 {agentName(ticketAgent)}
                  </a>
                </div>
                {reason && (
                  <div style={{ fontSize: 11.5, color: C.light, lineHeight: 1.5, marginTop: 6, textAlign: "center" }}>{reason}</div>
                )}
                {/* With a reason already said above it, only the commission,
                    so "we recommend" is not said twice in a row. */}
                {note && (
                  <div style={{ fontSize: 10.5, color: C.muted, lineHeight: 1.5, marginTop: 4, textAlign: "center" }}>{reason ? commissionOnly : note}</div>
                )}
              </div>
            );
          }
          // A Tiqets page that sells a guided tour or only the Copenhagen
          // Card is offered as exactly that, as a quieter line, never under a
          // Tickets label.
          if (offerAgent && !ticketSellsDoor) {
            const line = ticketOfferLine(ticketOffer, { lang, agent: ticketAgent });
            const icon = ticketOffer?.kind === "tour" ? "🧭" : "🎟️";
            return (
              <div data-testid="tiqets-second" style={{ marginTop: -4, marginBottom: 12, textAlign: "center" }}>
                <a href={href} target="_blank" rel={note ? "noreferrer sponsored nofollow" : "noreferrer"}
                  style={{ fontSize: 12, fontWeight: 600, color: C.gold, textDecoration: "none" }}>
                  {icon} {line} ↗
                </a>
                {note && (
                  <div style={{ fontSize: 10.5, color: C.muted, lineHeight: 1.5, marginTop: 3 }}>{note}</div>
                )}
              </div>
            );
          }
          const extra = offerAgent ? partnerReason(ticketOffer, { lang }) : "";
          return (
            <div style={{ marginBottom: 10 }}>
              <a href={href} target="_blank" rel={note ? "noreferrer sponsored nofollow" : "noreferrer"}
                style={{ display: "block", textAlign: "center", background: C.surface, border: `1px solid ${C.gold}55`, color: C.gold, borderRadius: 12, padding: "13px", fontSize: 13, fontWeight: 700, textDecoration: "none" }}>
                🎫 {uiT("entry.tickets", lang)}
              </a>
              {/* What the extra buys, when the page offers any. */}
              {extra && (
                <div style={{ fontSize: 11, color: C.light, lineHeight: 1.5, marginTop: 5, textAlign: "center" }}>{extra}</div>
              )}
              {note && (
                <div style={{ fontSize: 10.5, color: C.muted, lineHeight: 1.5, marginTop: 5, textAlign: "center" }}>{extra ? commissionOnly : note}</div>
              )}
            </div>
          );
        })()}

        {/* ── AND A SELF-GUIDED AUDIO WALK, WHERE THERE IS ONE ────
            Oliver, 6 Sep 2026: "add audio to this tour on the blogs that has
            the possible". WeGoTrip's thirteen Danish audio walks are every one
            of them about a TOWN rather than an attraction, so this only ever
            appears on a town or nightlife-town page. See utils/wegotripMatch.js
            and data/wegotrip.js.

            ITS OWN BUTTON, NOT THE TICKET ONE, because a walking tour is not
            admission and "🎫 Book tickets" over one is a label that is not
            true. Same rule that made ticketUrl refuse a Tiqets category page.

            The stored value is the plain WeGoTrip URL. Tracking is added here,
            at render, from the template in config.js, which is empty today: the
            reader still reaches the walk and Gemlyx earns nothing until the
            long-form Travelpayouts link is pasted in. affiliateNote returns ""
            in that state, so nothing claims a commission that is not earned. */}
        {(() => {
          // Resolved at the top of the component, beside the ticket, so this
          // button and the At a Glance row cannot disagree about which walk it
          // is or where it goes.
          if (!audioHref) return null;
          const href = audioHref, note = audioNote;
          return (
            <div style={{ marginBottom: 10 }}>
              <a href={href} target="_blank" rel={note ? "noreferrer sponsored nofollow" : "noreferrer"}
                style={{ display: "block", textAlign: "center", background: C.surface, border: `1px solid ${C.gold}55`, color: C.gold, borderRadius: 12, padding: "13px", fontSize: 13, fontWeight: 700, textDecoration: "none" }}>
                🎧 {audioLine(audioSaid)}
              </a>
              {/* NAMED, always. The Essentials row taught this one: a button
                  pointing at a site nobody has heard of has to say whose it is,
                  or the reader is asked to trust a stranger. */}
              <div style={{ fontSize: 10.5, color: C.muted, lineHeight: 1.5, marginTop: 5, textAlign: "center" }}>
                On WeGoTrip{note ? `. ${note}` : ""}
              </div>
            </div>
          );
        })()}

        <a href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(item.mapHint || `${item.name} ${item.city || item.location || ""} Denmark`)}`} target="_blank" rel="noreferrer"
          style={{ display: "block", textAlign: "center", background: color, color: "#fff", borderRadius: 12, padding: "15px", fontSize: 15, fontWeight: 700, textDecoration: "none" }}>
          ↗ {uiT("entry.directions", lang)}
        </a>

        {/* ── THE SOCIAL MEDIA SECTION ──────────────────────────────
            Oliver, 15 Sep: a section at the bottom, like the Instagram embed,
            that is NOT part of the draft. Below the directions button so the
            one thing a reader came for is not pushed down by it, and above the
            feedback block so the page still ends on the two things that are
            addressed to us rather than to the place. Renders nothing at all
            until the sweep has found accounts for this row. */}
        <SocialSection item={item} />

        {/* ── REPORTING AND REVIEWING, ABOVE THE PUBLIC COMMENTS ────
            Oliver, 1 Sep 2026. Deliberately ABOVE ReviewsSection and visually
            separate from it: that list is travellers talking to each other
            about the PLACE, and these two are a reader talking to us about the
            WRITING. Reading them as one thing is how a note meant for Oliver
            ends up published as somebody's opinion of a bar. */}
        <ArticleFeedback itemType={kind} itemName={item.name} signedIn={signedIn} onNeedAccount={onNeedAccount} />

        <ReviewsSection itemType={kind} itemName={item.name} />
      </div>
    </div>
    </div>
  );
};


